## ----setup, include = FALSE---------------------------------------------------
library(saemvs)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE, # montre le code
  results = "markup", # montre les sorties console
  message = TRUE, # garde les messages R
  warning = FALSE, # garde les warnings
  fig.show = "hold", # affiche les graphiques
  fig.align = "center",
  fig.width = 6,
  fig.height = 4
)

## -----------------------------------------------------------------------------
library(saemvs)

## -----------------------------------------------------------------------------
library(saemvs)
data("small_example_data")

## -----------------------------------------------------------------------------
# Create saemvsData object
saemvs_input <- saemvsData(
  y = small_example_data$y_list,
  t = small_example_data$t_list,
  x_candidates = small_example_data$x
)

## -----------------------------------------------------------------------------
# Define the model function
g <- function(phi, t) {
  phi[2] + phi[1] / (1 + exp(-(t - phi[3])))
}

# Create saemvsModel object
model <- saemvsModel(
  g = g,
  phi_dim = 3,
  phi_to_select_idx = c(1, 3)
)

## -----------------------------------------------------------------------------
# Define hyperparameters for the slab
hyper_slab <- saemvsHyperSlab(
  cov_re_prior_scale = diag(rep(0.2, 2)),
  cov_re_prior_df = 4
)

## -----------------------------------------------------------------------------
# Define tuning parameters
tuning <- saemvsTuning(
  niter = 1000,
  nburnin = 800,
  spike_values_grid = exp(-3 + seq(1, 8)) # /3
)

## -----------------------------------------------------------------------------
# Define initial values
init_values <- saemvsInit(
  intercept = c(1300, 350, 250),
  beta_candidates = matrix(
    c(
      80, 20, 20, 0,
      0, 0, 0, 0,
      15, 0, 0, 0
    ),
    ncol = 3
  ),
  cov_re = diag(c(400, 200, 200)),
  sigma2 = 100
)

## ----run_saemvs, cache = FALSE, eval = FALSE----------------------------------
#  # Run the SAEMVS algorithm
#  result <- saemvs(
#    data = saemvs_input,
#    model = model,
#    init = init_values,
#    tuning_algo = tuning,
#    hyperparam = hyper_slab,
#    pen = "e-BIC"
#  )

## ----saemvs_summary, eval = FALSE---------------------------------------------
#  summary_saemvs(result, digits = 3)

## ----saemvs_plot, eval = FALSE------------------------------------------------
#  plots <- prepare_grid_plot(result)
#  plots$reg_plot[[1]]
#  plots$reg_plot[[2]]
#  
#  plots$ebic_plot

## -----------------------------------------------------------------------------
model_with_fixed_effects <- saemvsModel(
  g = g,
  phi_dim = 3,
  phi_to_select_idx = c(1, 3),
  phi_fixed_idx = 2
)

init_values_with_fixed_effects <- saemvsInit(
  intercept = c(1300, 350, 250),
  beta_candidates = matrix(
    c(
      80, 20, 20, 0,
      0, 0, 0, 0,
      15, 0, 0, 0
    ),
    ncol = 3
  ),
  cov_re = diag(c(400, 200, 200)),
  sigma2 = 100
)

## ----run_saemvs_fixed_effects, cache = FALSE, eval = FALSE--------------------
#  # Run the SAEMVS algorithm
#  result_with_fixed_effects <- saemvs(
#    data = saemvs_input,
#    model = model_with_fixed_effects,
#    init = init_values_with_fixed_effects,
#    tuning_algo = tuning,
#    hyperparam = hyper_slab,
#    pen = "e-BIC"
#  )
#  
#  summary_saemvs(result_with_fixed_effects, digits = 3)

## -----------------------------------------------------------------------------
saemvs_input_with_forced_covariates <- saemvsData(
  y = small_example_data$y_list,
  t = small_example_data$t_list,
  x_candidates = small_example_data$x[, -1],
  x_forced = small_example_data$x[, 1, drop = FALSE]
)

model_with_forced_covariates <- saemvsModel(
  g = g,
  phi_dim = 3,
  phi_to_select_idx = c(1, 3),
  x_forced_support = matrix(c(1, 0, 1), ncol = 3, nrow = 1)
)

init_values_with_forced_covariates <- saemvsInit(
  intercept = c(1300, 350, 250),
  beta_candidates = matrix(
    c(
      20, 20, 0,
      0, 0, 0,
      0, 0, 0
    ),
    ncol = 3
  ),
  beta_forced = matrix(
    c(80, 0, 15),
    ncol = 3, nrow = 1
  ),
  cov_re = diag(c(400, 200, 200)),
  sigma2 = 100
)

## ----run_saemvs_forced_covariates, cache = FALSE, eval = FALSE----------------
#  result_with_forced_covariates <- saemvs(
#    data = saemvs_input_with_forced_covariates,
#    model = model_with_forced_covariates,
#    init = init_values_with_forced_covariates,
#    tuning_algo = tuning,
#    hyperparam = hyper_slab,
#    pen = "e-BIC"
#  )
#  
#  summary_saemvs(result_with_forced_covariates, digits = 3)

## ----run_saemvs_bic, cache = FALSE, eval = FALSE------------------------------
#  # Run the SAEMVS algorithm
#  result_with_bic <- saemvs(
#    data = saemvs_input,
#    model = model,
#    init = init_values,
#    tuning_algo = tuning,
#    hyperparam = hyper_slab,
#    pen = "BIC"
#  )
#  
#  summary_saemvs(result_with_bic, digits = 3)

## ----bic_plot, eval = FALSE---------------------------------------------------
#  plots <- prepare_grid_plot(result_with_bic)
#  plots$reg_plot[[1]]
#  plots$reg_plot[[2]]
#  
#  plots$ebic_plot

## -----------------------------------------------------------------------------
tuning_workers <- saemvsTuning(
  niter = 1000,
  nburnin = 800,
  spike_values_grid = exp(-3 + seq(1, 8)),
  nb_workers = 8
)

