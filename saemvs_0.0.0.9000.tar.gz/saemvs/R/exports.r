#' @useDynLib saemvs, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL

# Fonctions exportées
# p_star_cpp, mat_inv, solve_linear_syst, ...
